const fs = require('fs');
const express = require('express');
const { error } = require('console');
const e = require('express');
const app = express();
app.use(express.json());//解析JSON请求体
app.use(express.static('public'));//设置静态文件目录
app.post('/data', (req, res) => {
    fs.writeFile('data/form.json', JSON.stringify(req.body), (error) => {
        if(error){
            res.status(500).send('Error writing file');
            console.log('Error writing file:');
        }
    });
        res.json(req.body)})
app.get('/', (req, res) => {
    fs.readFile('data/form.json', 'utf8', (error, data) => {
        if (error) {
            res.status(500).send('Error reading file');
            console.log('Error reading file:');
            return;
        }else {
            // res.setHeader('Content-Type', 'application/json');
            console.log(data);
            console.log(data.toString());
            // res.end(data.toString());
            res.json(data);
        }
    });
});
   
const port = 3000;

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});

// app.get('/', (req, res) => {
//   res.send('Hello World!');
// });