package utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtil {
    public static void setUpCostByLevel(String level, Integer needPoints){
        // 定义属性文件路径
        String filePath = "D:\\studyFiles\\数据库原理\\课程设计\\my_sale\\my_sale\\src\\main\\resources\\member.properties";

        // 创建Properties对象
        Properties properties = new Properties();

        try {
            // 加载属性文件
            FileInputStream fileInputStream = new FileInputStream(filePath);
            properties.load(fileInputStream);
            fileInputStream.close();

            // 修改属性值
            properties.setProperty(level, String.valueOf(needPoints));

            // 保存属性文件
            FileOutputStream fileOutputStream = new FileOutputStream(filePath);
            properties.store(fileOutputStream, "Updated properties file");
            fileOutputStream.close();
//            System.out.println("Properties file updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void setDiscountByLevel(String level, double discount){
        // 定义属性文件路径
        String filePath = "D:\\studyFiles\\数据库原理\\课程设计\\my_sale\\my_sale\\src\\main\\resources\\memberDiscount.properties";

        // 创建Properties对象
        Properties properties = new Properties();

        try {
            // 加载属性文件
            FileInputStream fileInputStream = new FileInputStream(filePath);
            properties.load(fileInputStream);
            fileInputStream.close();

            // 修改属性值
            properties.setProperty(level, String.valueOf(discount));

            // 保存属性文件
            FileOutputStream fileOutputStream = new FileOutputStream(filePath);
            properties.store(fileOutputStream, "Updated properties file");
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void setRatio(Integer ratio){
        // 定义属性文件路径
        String filePath = "D:\\studyFiles\\数据库原理\\课程设计\\my_sale\\my_sale\\src\\main\\resources\\memberDiscount.properties";

        // 创建Properties对象
        Properties properties = new Properties();

        try {
            // 加载属性文件
            FileInputStream fileInputStream = new FileInputStream(filePath);
            properties.load(fileInputStream);
            fileInputStream.close();

            // 修改属性值
            properties.setProperty("points_consumed", String.valueOf(ratio));

            // 保存属性文件
            FileOutputStream fileOutputStream = new FileOutputStream(filePath);
            properties.store(fileOutputStream, "Updated properties file");
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
