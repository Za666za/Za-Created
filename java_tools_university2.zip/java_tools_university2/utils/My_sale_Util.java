package utils;

import jakarta.servlet.http.HttpServletRequest;

import java.io.InputStream;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

public class My_sale_Util {
    public static int radio(){
        try {
            //0.读取配置文件的配置信息
            InputStream in = JDBCUtils.class.getClassLoader().getResourceAsStream("memberDiscount.properties");
            Properties properties = new Properties();
            properties.load(in);
            return Integer.parseInt(properties.getProperty("points_consumed"));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static int getPageSize() {
        try {
            //0.读取配置文件的配置信息
            InputStream in = JDBCUtils.class.getClassLoader().getResourceAsStream("page.properties");
            Properties properties = new Properties();
            properties.load(in);
            return Integer.parseInt(properties.getProperty("pageSize"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static String getAction(HttpServletRequest req) {
        String uri = req.getRequestURI();
        return uri.substring(uri.lastIndexOf("/") + 1);
    }
    public static int getNeedScore(String level) {
        try {
            //0.读取配置文件的配置信息
            InputStream in = JDBCUtils.class.getClassLoader().getResourceAsStream("member.properties");
            Properties properties = new Properties();
            properties.load(in);
            return Integer.parseInt(properties.getProperty(level));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static double getDiscount(String level) {
        try {
            //0.读取配置文件的配置信息
            InputStream in = JDBCUtils.class.getClassLoader().getResourceAsStream("memberDiscount.properties");
            Properties properties = new Properties();
            properties.load(in);
            return Double.parseDouble(properties.getProperty(level));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static Integer generateSevenDigitUniqueNumber() {
        Random random = new Random();
        Set<Integer> usedDigits = new HashSet<>();

        StringBuilder result = new StringBuilder();

        // 第一位（1-9）
        int firstDigit = random.nextInt(9) + 1;
        usedDigits.add(firstDigit);
        result.append(firstDigit);

        // 后6位（0-9不重复）
        while (result.length() < 7) {
            int digit = random.nextInt(10);
            if (!usedDigits.contains(digit)) {
                usedDigits.add(digit);
                result.append(digit);
            }
        }

        return Integer.parseInt(result.toString());
    }
    public static String generateSevenDigitUniqueNumberString() {
        Random random = new Random();
        Set<Integer> usedDigits = new HashSet<>();

        StringBuilder result = new StringBuilder();

        // 第一位（1-9）
        int firstDigit = random.nextInt(9) + 1;
        usedDigits.add(firstDigit);
        result.append(firstDigit);

        // 后6位（0-9不重复）
        while (result.length() < 7) {
            int digit = random.nextInt(10);
            if (!usedDigits.contains(digit)) {
                usedDigits.add(digit);
                result.append(digit);
            }
        }

        return result.toString();
    }
    public static Date StringToDate(String dateString) {

        // 定义日期格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            // 将字符串转换为Date对象
            return  (Date) sdf.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static double saveTwo(double num){
        double roundedNumber = Math.round(num * 100.0) / 100.0;
        return roundedNumber;
    }
    public static double pointToMoney(int point){
        try {
            //0.读取配置文件的配置信息
            InputStream in = JDBCUtils.class.getClassLoader().getResourceAsStream("memberDiscount.properties");
            Properties properties = new Properties();
            properties.load(in);
            int points_consumed = Integer.parseInt(properties.getProperty("points_consumed"));
            return My_sale_Util.saveTwo((double) point /points_consumed);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
